# Pip Sandbox: project memory

Claude Code reads this automatically. Keep it short.

## What this is
Pip Sandbox is Aaron's **dream** playground for Glass Clock. It never ships.
- Glass Clock (the iPad app) is the grounded version. The Glass Clock Progress dashboard sits between the two.
- Don't merge the projects. Parts move between them one at a time, and only when Aaron says yes.
- This folder is a copy of the live claude.ai artifact "Pip Sandbox" (version 1793312605-ed46, taken 30 Oct 2026). The two "Pip Sandbox (Copy)" artifacts are backups and stay untouched.

## How it's built
- `index.html` loads `tokens.css`, `styles.css` and `skins.css` (the era looks), then a loader script.
- The loader fetches five scripts, joins them **in this order** and runs them inside one `(() => { ... })()`: `core.js`, `pip.js` (the companion), `extras.js` (time machine and crash game), `engine.js` (physics, render, layout, boot) and `host.js` (plugin host, `window.PipHost`).
- They share variables, so none of them works on its own. Making Pip a portable module is a future job: ask Aaron before starting it.
- **Plugins** live in `plugins/` (32 at the moment). They're listed in the `PLUGINS` array in `index.html` with id, name, version, file, shelf (dream / grounded / trial), icon and a one-line `what`.
  - To add one, drop the file in `plugins/` and add a line to that array.
  - A plugin that throws is switched off by the host; the sandbox keeps running.
- See `PLUGIN-SPEC.md` for the plugin shape and the `PipHost` API.
- Settings save to localStorage keys starting `gs2-`. Plugins switched off are kept in `gs2-pluginsOff`.
- `data/dashboard.json` feeds the Dashboard Link plugin.

## Run and test
- The loader uses `fetch`, so opening the file directly won't work. Serve the folder:
  `python3 -m http.server 8765`, then open http://localhost:8765
- Headless check (optional; needs `npm i playwright` and `npx playwright install chromium` once):
  `node tools/boot.js`. It boots at iPad landscape and portrait sizes and prints plugin status and errors. Screenshots go to `tools/`.
- Last check (30 Oct, headless only): the core and host loaded, all 32 plugins were on, no sandbox errors. Google Fonts, esm.sh and the status gist were blocked by that test machine's network, not by bugs.
- **Nothing has been tested on an iPad** unless Aaron says so.

## Rules for the work
- Prefer a new plugin to editing the core files. If the core must change, keep the edit small and in one file.
- Write plugins data first, logic second, DOM last (they port to SwiftUI later).
- Must feel great with Pip switched off (`S.naviOn`).
- Calm by default, overdo-able in settings. No guilt, streaks or grind. Pip never sells.
- Respect reduced motion (`H.simpler()`: fade, don't move). Add VoiceOver labels.
- Homage only: make-believe names, no real brands or people.
- Pip's pronoun is the user's choice (default they).
- Keep the grab-and-flick interaction.

## Pip
- Pip is a personal, non-AI companion inspired by old low-memory games.
- Its job is walking people through the app, scaling up or down to the user and the area of the app they're in.
- It's customisable, with retro era skins over the glass style.
- In Panels mode it's playfully grumpy, with a one-tap way to calm it.

## Proposed keep list (not built, needs Aaron's yes)
- Personal Pip: goes to the app later.
- Flick: goes to the dashboard, then the app.
- Glass tokens: go to the design system.
- Grumpy Pip: later.

## Working with Aaron
- He's design director. He sets the look and the rules (radii, spacing); you do the repetitive building. Keep his sketching and design thinking in the loop.
- Be credit-aware: make targeted edits, and batch changes before publishing.
- Challenge anything that overcomplicates things, and suggest the simpler option.
- Small changes: just do them. Big ones: ask a quick question or add them to the list first.
- Say clearly what's an estimate and what you couldn't test.
- Tell him straight away when you need his help (a setup step, access, a command).
- Short plain updates. Don't ask what you can decide.
- Don't touch the dashboard, the app repo or the old copies without asking.

## Getting changes back into the artifact
- This folder isn't linked to the claude.ai artifact.
- To publish, either take the changed files back to a claude.ai chat that can publish to "Pip Sandbox" (republish only the changed files), or use a Claude artifacts connector if one is set up in Claude Code.
- Before the first publish, check the live version is still 1793312605-ed46, so nothing newer gets overwritten.
